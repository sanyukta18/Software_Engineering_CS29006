#include <iostream>
#include <string>
#include "road.hpp"
using namespace std;

int Road::sRoadCount = 1;

/*
int main() {
    Road p = Road("MVL Maarg");
    Road q = Road("Lal Bahadur Shaastri");

    cout<<p<<endl<<q;
}*/