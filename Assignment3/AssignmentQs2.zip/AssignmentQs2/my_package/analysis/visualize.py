#Imports
import cv2
from PIL import Image
import matplotlib.pyplot as plt
import os

def plot_boxes(self,annotation_file,pred_boxes,pred_class,pred_score,idx,flag): # Write the required arguments
    
    fp = open(annotation_file)
    #           You need to do the following, 
    #             1. Extract the correct annotation using the idx provided.
    find_str = str(idx)+".jpg"
    for line in Lines:
        if find_str in line:
            f_in = line
            break 
            
    font = cv2.FONT_HERSHEY_SIMPLEX 
            
#             2. Read the image and convert it into a numpy array (wont be necessary
#                 with some libraries). The shape of the array would be (3, H, W).
     i = 0
     imag = str(idx)+".jpg"
        
   
     im = Image.open("./data/imgs/"+imag) 
     
        
    
     image = cv2.imread(im)
        
     
     k = Image.open("./data/imgs/"+imag)
    
     org = (start_point)
 
     while i < 5:
            start_point = pred_boxes[i][0] 
            end_point = pred_boxes[i][1] 
            org = start_point
            i = i+1
            color = (0, 0, 255) 
            font = cv2.FONT_HERSHEY_SIMPLEX 
#         img = cv2.imread("/home/sanyukta/2nd_year/sem4/Software Engineering/Labs/img1.jpg")
            fontScale = 1
            # Blue color in BGR 
            color = (0, 0, 255) 
        # Line thickness of 2 px 
            thickness = 1
        # Using cv2.putText() method 
            image = cv2.putText(img,str(pred_class[i]),org,font, 
                        fontScale, color, thickness, cv2.LINE_AA) 
            image = cv2.rectangle(img, start_point, end_point, color, thickness) 

        
    if flag == 0:
        directory = "/home/sanyukta/2nd_year/sem4/Software Engineering/Labs/AssignmentQs2/data/imgs"
        filename = "img"+str(idx)+".jpg"
        cv2.imwrite(filename, img) 
        path = directory
        cv2.imwrite(os.path.join(path ,filename),img)
        
    if flag == 1:
        directory = "/home/sanyukta/2nd_year/sem4/Software Engineering/Labs/AssignmentQs2/output_folder"
        my_dpi = 50
        fig,axes = plt.subplots(nrows=4, ncols=2, figsize=(20,20), dpi=my_dpi)
        print(fig)
        plt.imshow(img, cmap='gray')
        plt.axis('off')
        

   
  # The function should plot the predicted boxes on the images and save them.
  # Tip: keep the dimensions of the output image less than 800 to avoid RAM crashes.
  
  