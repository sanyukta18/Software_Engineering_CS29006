#Imports

from PIL import Image
class CropImage(object):
#     '''
#         Performs either random cropping or center cropping.
#     '''

    def __init__(self, shape=[1,1], crop_type='center'):
#         '''
#             Arguments:
#             shape: output shape of the crop (h, w)
#             crop_type: center crop or random crop. Default: center
#         '''
        self._width = shape[0]
        self._height = shape[1]

        # Write your code here

    def __call__(self, image):
#         '''
#             Arguments:
#             image (numpy array or PIL image)

#             Returns:
#             image (numpy array or PIL image)
#         '''
         # Write your code here
            left = (self._width)/4
            top = (self._height)/4
            right = 3 * (self._width)/4
            bottom = 3 * (self._height)/4
            cropped_example = image.crop((left, top, right, bottom))
            
            return cropped_example
       

        

 