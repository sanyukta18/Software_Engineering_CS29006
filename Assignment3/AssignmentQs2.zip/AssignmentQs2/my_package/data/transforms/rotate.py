#Imports
from PIL import Image

class RotateImage(object):
#     '''
#         Rotates the image about the centre of the image.
#     '''

    def __init__(self, degrees=90):
#         '''
#             Arguments:
#             degrees: rotation degree.
#         '''
        
        # Write your code here
        self._deg = degrees
    def __call__(self, sample):
#         '''
#             Arguments:
#             image (numpy array or PIL image)

#             Returns:
#             image (numpy array or PIL image)
#         '''

        # Write your code here
        rotate_img= sample.rotate(self._deg)
        return rotate_img