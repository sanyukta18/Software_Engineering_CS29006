#Imports
from PIL import Image

class RescaleImage(object):
#     '''
#         Rescales the image to a given size.
#     '''

    def __init__(self, output_size = 10):
#         '''
#             Arguments:
#             output_size (tuple or int): Desired output size. If tuple, output is
#             matched to output_size. If int, smaller of image edges is matched
#             to output_size keeping aspect ratio the same.
#         '''

        # Write your code here
        self.op_size = output_size 

    def __call__(self, image):
#         '''
#             Arguments:
#             image (numpy array or PIL image)

#             Returns:
#             image (numpy array or PIL image)

#             Note: You do not need to resize the bounding boxes. ONLY RESIZE THE IMAGE.
#         '''

        # Write your code here
        width, height = image.size
        if isinstance(self.op_size,tuple):
            new_image = image.resize(op_size[0],op_size[1])
            return new_image
        
        if isinstance(self.op_size,int):
            if width < height:
                width = self.op_size
                new_image = image.resize(width,height)
                return new_image
            else:
                height = self.op_size
                new_image = image.resize(width,height)
                return new_image
        