#Imports
from my_package.model import ObjectDetectionModel
from my_package.data import Dataset
from my_package.analysis import plot_boxes
from my_package.data.transforms import FlipImage, RescaleImage, BlurImage, CropImage, RotateImage
from PIL import Image
import matplotlib.pyplot as plt

def experiment(annotation_file, detector, transforms, outputs):
    '''
        Function to perform the desired experiments

        Arguments:
        annotation_file: Path to annotation file
        detector: The object detector
        transforms: List of transformation classes
        outputs: path of the output folder to store the images
    '''
    
    #Create the instance of the dataset.
#     fp = input("Give annoitation file path")
    #     l_tr = input("Give list of transformations")
    d = Dataset()
    I = {}
    L_dict = []
    path = open(annotation_file)
    length = 0
    Lines = path.readlines()
    for line in Lines:
        length += 1
    #Iterate over all data items
    t = 0
    while t<length:
        d(fp)
        I = d[t+1]
        L_dict.append(I)
        t = t+1

        
    #Get the predictions from the detector. 
    L = []
    for i in L_dict:
        for state in i:
             L.append(detector(state))

    #Draw the boxes on the image and save them
    j = 0
    for x in L:
        while j<length:
            plot_boxes(fp,L[j][0],L[j][1],L[j][2],j,0)
        j = j+1

    #Do the required analysis experiments.
#     path1 = "/home/sanyukta/2nd_year/sem4/Software Engineering/Labs/AssignmentQs2/data/imgs/6.jpg"
#     c(fp,
#     I = {}
#     I = d[6]
#     for i in I:
#         detector(i)


def main():
    detector = ObjectDetectionModel()
    outputs = "/home/sanyukta/2nd_year/sem4/Software Engineering/Labs/AssignmentQs2/data/imgs"
    annotation_file = "/home/sanyukta/2nd_year/sem4/Software"
    annotation_file =  annotation_file+"Engineering/Labs/AssignmentQs2/data/annotations.jsonl"
    experiment(annotation_file, detector, [FlipImage(), BlurImage()], outputs) # Sample arguments to call experiment()



if __name__ == '__main__':
    main()